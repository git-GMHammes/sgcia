// C:\laragon\www\sgcpro\src\public\script\react_modelo_v1\frontend\src\pages\Circuito\AppListarConteudo.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Eye, Edit, Trash2 } from 'lucide-react';
import { Plus } from 'lucide-react';
import CircuitoService from '../../src/public/script/react_modelo_v1/frontend/src/services/circuito';
import './styles.css';

const AppListarConteudo = () => {
  const navigate = useNavigate();
  const [circuitos, setCircuitos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filtro, setFiltro] = useState('');
  const [paginaAtual, setPaginaAtual] = useState(1);
  // Adicionando estados para controle de paginação da API
  const [itensPorPagina, setItensPorPagina] = useState(10);
  const [totalItens, setTotalItens] = useState(0);
  const [metadados, setMetadados] = useState(null);

  // Função para formatar data
  const formatarData = (dataString) => {
    if (!dataString) return '-';
    const data = new Date(dataString);
    return data.toLocaleDateString('pt-BR');
  };

  // Modificado useEffect
  useEffect(() => {
    const fetchCircuitos = async () => {
      console.log(`useEffect disparado - paginaAtual: ${paginaAtual}, itensPorPagina: ${itensPorPagina}`);

      setLoading(true);
      setError(null);

      try {
        const data = await CircuitoService.getAll(paginaAtual, itensPorPagina);
        console.log('Dados recebidos no useEffect:', data);
        console.log('É um array?', Array.isArray(data));
        console.log('Comprimento:', data.length);

        if (Array.isArray(data)) {
          // Clone o array para garantir que React detecte a mudança
          setCircuitos([...data]);

          // Verificar e armazenar metadados
          if (data._metadata) {
            console.log('Metadados encontrados:', data._metadata);
            setMetadados({ ...data._metadata });

            // Se houver informação sobre o total de itens nos metadados, armazená-la
            if (data._metadata.metadata && data._metadata.metadata.total) {
              setTotalItens(data._metadata.metadata.total);
            }
          } else if (window._circuitosMetadata) {
            console.log('Metadados globais encontrados:', window._circuitosMetadata);
            setMetadados({ ...window._circuitosMetadata });
          }
        } else {
          console.error('Dados recebidos não são um array');
          setCircuitos([]);
        }
      } catch (err) {
        console.error('Erro ao buscar circuitos:', err);
        setError('Não foi possível carregar a lista de circuitos. Por favor, tente novamente.');
        setCircuitos([]);
      } finally {
        setLoading(false);
      }
    };

    fetchCircuitos();
  }, [paginaAtual, itensPorPagina]);

  // Filtrar circuitos - com verificação se é um array
  const circuitosFiltrados = Array.isArray(circuitos)
    ? circuitos.filter(circuito =>
      circuito.nome?.toLowerCase().includes(filtro.toLowerCase()) ||
      circuito.sigla?.toLowerCase().includes(filtro.toLowerCase()) ||
      circuito.SEI?.toLowerCase().includes(filtro.toLowerCase())
    )
    : [];

  // Calcular paginação local (quando não há metadados de paginação da API)
  const totalPaginas = Math.ceil(circuitosFiltrados.length / itensPorPagina);
  const indiceInicial = (paginaAtual - 1) * itensPorPagina;
  const indiceFinal = indiceInicial + itensPorPagina;
  const circuitosPaginados = circuitosFiltrados.slice(indiceInicial, indiceFinal);

  // Adicionar um manipulador para mudar o número de itens por página
  const handleItensPorPaginaChange = (e) => {
    const novoValor = parseInt(e.target.value, 10);
    setItensPorPagina(novoValor);
    setPaginaAtual(1); // Voltar para a primeira página ao mudar o limite
  };

  // Adicionar um seletor de itens por página no componente
  const renderizarSeletorItensPorPagina = () => (
    <div className="form-inline my-2">
      <label className="mr-2">Itens por página:</label>
      <select
        className="form-control form-control-sm"
        value={itensPorPagina}
        onChange={handleItensPorPaginaChange}
      >
        <option value="5">5</option>
        <option value="10">10</option>
        <option value="25">25</option>
        <option value="50">50</option>
        <option value="100">100</option>
      </select>
    </div>
  );

  // Modificar o manipulador de clique de paginação para chamar a API
  const handlePaginaApiClick = async (event, href) => {
    event.preventDefault();

    console.log('Clique na paginação detectado');
    console.log('href recebido:', href);

    // Extrair número da página do href (ex: "?page=2")
    const pageMatch = href.match(/page=(\d+)/);
    const limitMatch = href.match(/limit=(\d+)/);

    console.log('Match de página:', pageMatch);
    console.log('Match de limite:', limitMatch);

    if (pageMatch && pageMatch[1]) {
      const numeroPagina = parseInt(pageMatch[1], 10);

      // Se tiver um limit, usá-lo; senão, manter o atual
      const novoLimit = limitMatch && limitMatch[1] ?
        parseInt(limitMatch[1], 10) : itensPorPagina;

      console.log(`Mudando para página ${numeroPagina} com ${novoLimit} itens por página`);

      // Importante: Defina o estado de loading antes de buscar os dados
      setLoading(true);

      try {
        console.log(`Chamando API para buscar página ${numeroPagina}`);

        // Buscar dados antes de atualizar os estados de página
        const data = await CircuitoService.getPage(numeroPagina, novoLimit);
        console.log('Dados recebidos da API:', data);
        console.log('Quantidade de itens recebidos:', Array.isArray(data) ? data.length : 'Dados não são um array');

        // Atualizar o estado com os novos dados
        if (Array.isArray(data)) {
          // Importante: criar uma nova array para forçar React a detectar mudança
          setCircuitos([...data]);

          // Depois de atualizar os dados, atualize os estados de paginação
          setPaginaAtual(numeroPagina);
          if (novoLimit !== itensPorPagina) {
            setItensPorPagina(novoLimit);
          }

          // Verificar se os dados têm metadados anexados
          if (data._metadata) {
            console.log('Novos metadados recebidos:', data._metadata);
            // Clone os metadados para garantir que React detecte a mudança
            setMetadados({ ...data._metadata });
          } else if (window._circuitosMetadata) {
            console.log('Usando metadados globais:', window._circuitosMetadata);
            setMetadados({ ...window._circuitosMetadata });
          } else {
            console.log('Nenhum metadado disponível');
          }
        } else {
          console.error('Resposta da API não é um array:', data);
          setError('Formato de resposta inesperado da API.');
          setCircuitos([]);
        }
      } catch (err) {
        console.error(`Erro ao buscar página ${numeroPagina}:`, err);
        setError('Não foi possível carregar a página solicitada.');
        setCircuitos([]);
      } finally {
        setLoading(false);
      }
    } else {
      console.warn('Não foi possível extrair o número da página do href:', href);
    }
  };

  // Manipulador de exclusão
  const handleExcluir = async (id) => {
    if (window.confirm('Tem certeza que deseja excluir este circuito?')) {
      try {
        await CircuitoService.delete(id);
        setCircuitos(circuitos.filter(circuito => circuito.id !== id));
      } catch (err) {
        console.error('Erro ao excluir circuito:', err);
        alert('Erro ao excluir circuito. Por favor, tente novamente.');
      }
    }
  };

  // Determinar se devemos usar a paginação da API ou local
  const usarPaginacaoApi = metadados && metadados.paginacao && metadados.paginacao.length > 0;

  // Renderizar links de paginação baseados nos metadados da API
  const renderizarPaginacaoApi = () => {
    if (!metadados || !metadados.paginacao) return null;

    // Limpar e processar os links para exibição adequada
    const links = metadados.paginacao.map(link => {
      // Limpar texto removendo espaços e quebras de linha
      const texto = link.text.trim().replace(/\r?\n|\r/g, '');
      return {
        ...link,
        cleanText: texto,
        isActive: texto === paginaAtual.toString()
      };
    });

    // Encontrar links especiais
    const primeiroLink = links.find(link => link.cleanText === '1');
    const anteriorLink = links.find(link => link.cleanText === 'Anterior');
    const proximoLink = links.find(link => link.cleanText === 'Próximo');
    const ultimoLink = links.find(link => link.cleanText === 'Último');

    // Links numéricos (excluindo controles de navegação)
    const paginasNumericas = links.filter(link =>
      !isNaN(parseInt(link.cleanText, 10)) &&
      link.cleanText !== 'Anterior' &&
      link.cleanText !== 'Próximo' &&
      link.cleanText !== 'Último'
    );

    return (
      <div className="table">
        {/* Campos de Filtro */}
        <div className="row mb-3">
          <div className="col-md-3">
            <label className="form-label">Secretaria</label>
            <input type="text" className="form-control" placeholder="Digite a Secretaria..." />
          </div>
          <div className="col-md-3">
            <label className="form-label">Designação</label>
            <input type="text" className="form-control" placeholder="Digite a Designação..." />
          </div>
          <div className="col-md-3">
            <label className="form-label">Lote</label>
            <select className="form-select">
              <option value="">Todos</option>
              <option value="Lote 1 MPLS">Lote 1 MPLS</option>
              <option value="Lote 2 VPN">Lote 2 VPN</option>
            </select>
          </div>
          <div className="col-md-3">
            <label className="form-label">Link</label>
            <input type="text" className="form-control" placeholder="Digite a Link..." />
          </div>
          <div className="col-md-3">
            <label className="form-label">Data da ativação</label>
            <input type="month" className="form-control" />
          </div>
          <div className="col-md-3">
            <label className="form-label">Data de cancelamento</label>
            <input type="month" className="form-control" />
          </div>
          <div className="col-md-3">
            <label className="form-label">Status</label>
            <input type="text" className="form-control" placeholder="Digite a Status..." />
          </div>
          <div className="col-md-3">
            <label className="form-label">SEI</label>
            <input type="text" className="form-control" placeholder="Digite a SEI..." />
          </div>
        </div>

        <button className="btn btn-primary mb-3">Aplicar Filtros</button>
        <table className="table table-striped table-hover">
          <thead className="table-dark">
            <tr>
              <th scope="col">Secretaria</th>
              <th scope="col">Designação</th>
              <th scope="col">Endereço</th>
              <th scope="col">Lote</th>
              <th scope="col">Produto</th>
              <th scope="col">Link</th>
              <th scope="col">Valor Unitário</th>
              <th scope="col">Data Ativação</th>
              <th scope="col">Data Cancelamento</th>
              <th scope="col">Status</th>
              <th scope="col">SEI</th>
              <th scope="col">Ações</th>
            </tr>
          </thead>
          <tbody>
            {circuitos.map(circuito => (
              <tr key={circuito.id}>
                <td>{circuito.id}</td>
                <td>{circuito.nome}</td>
                <td>{circuito.sigla}</td>
                <td>
                  <span
                    className={`badge ${circuito.status === 'Ativo' ? 'bg-success' : 'bg-warning'}`}
                  >
                    {circuito.status}
                  </span>
                </td>
                <td>{formatarData(circuito.data_ativacao)}</td>
                <td>{formatarData(circuito.data_cancelamento)}</td>
                <td>{circuito.SEI}</td>
                <td>
                  <div className="btn-group" role="group">
                    <button
                      type="button"
                      className="btn btn-sm btn-outline-primary btn-action"
                      onClick={() => navigate(`/circuito/consultar/${circuito.id}`)}
                      title="Visualizar"
                    >
                      <Eye size={16} />
                    </button>
                    <button
                      type="button"
                      className="btn btn-sm btn-outline-secondary btn-action"
                      onClick={() => navigate(`/circuito/atualizar/${circuito.id}`)}
                      title="Editar"
                    >
                      <Edit size={16} />
                    </button>
                    <button
                      type="button"
                      className="btn btn-sm btn-outline-danger btn-action"
                      onClick={() => onExcluir(circuito.id)}
                      title="Excluir"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };
};

export default AppListarConteudo;