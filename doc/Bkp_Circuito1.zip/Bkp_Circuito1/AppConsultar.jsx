// C:\laragon\www\sgcpro\src\public\script\react_modelo_v1\frontend\src\pages\Circuito\AppConsultar.jsx
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Edit } from 'lucide-react';
import CircuitoService from '../../services/circuito';
import './styles.css';

const AppConsultar = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [circuito, setCircuito] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [secretarias, setSecretarias] = useState(null);
  const [velocidade, setVelocidade] = useState(null);
  const [endereco, setEndereco] = useState(null);

  useEffect(() => {
    const fetchCircuito = async () => {
      if (!id) {
        setError('ID do circuito não fornecido');
        setLoading(false);
        return;
      }

      try {
        const data = await CircuitoService.getById(id);
        setCircuito(data);

        // Buscar dados relacionados
        const secretariaData = await CircuitoService.getSecretarias().then(
          secretarias => secretarias.find(c => c.id === parseInt(data.cadastro_secretaria_id))
        );
        setSecretarias(secretariaData);

        const velocidadeData = await CircuitoService.getVelocidades().then(
          velocidades => velocidades.find(v => v.id === parseInt(data.velocidade_id))
        );
        setVelocidade(velocidadeData);

        const enderecoData = await CircuitoService.getEnderecos().then(
          enderecos => enderecos.find(e => e.id === parseInt(data.endereco_id))
        );
        setEndereco(enderecoData);
      } catch (err) {
        console.error('Erro ao buscar dados do circuito:', err);
        setError('Não foi possível carregar os dados do circuito. Por favor, tente novamente.');
      } finally {
        setLoading(false);
      }
    };

    fetchCircuito();
  }, [id]);

  if (loading) {
    return (
      <div className="container mt-4">
        <div className="card">
          <div className="card-header bg-primary text-white">
            <h2 className="mb-0">Detalhes do Circuito</h2>
          </div>
          <div className="card-body text-center">
            <div className="spinner-border text-primary" role="status">
              <span className="visually-hidden">Carregando...</span>
            </div>
            <p className="mt-2">Carregando dados do circuito...</p>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mt-4">
        <div className="card">
          <div className="card-header bg-primary text-white">
            <h2 className="mb-0">Detalhes do Circuito</h2>
          </div>
          <div className="card-body">
            <div className="alert alert-danger" role="alert">
              {error}
            </div>
            <button
              onClick={() => navigate('/circuito/listar')}
              className="btn btn-primary"
            >
              Voltar para Lista
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (!circuito) {
    return (
      <div className="container mt-4">
        <div className="card">
          <div className="card-header bg-primary text-white">
            <h2 className="mb-0">Detalhes do Circuito</h2>
          </div>
          <div className="card-body">
            <div className="alert alert-warning" role="alert">
              Circuito não encontrado.
            </div>
            <button
              onClick={() => navigate('/circuito/listar')}
              className="btn btn-primary"
            >
              Voltar para Lista
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mt-4">
      <div className="card">
        <div className="card-header bg-primary text-white d-flex justify-content-between align-items-center">
          <h2 className="mb-0">Detalhes do Circuito</h2>
          <button
            className="btn btn-light"
            onClick={() => navigate(`/circuito/atualizar/${id}`)}
          >
            <Edit size={18} className="me-1" /> Editar
          </button>
        </div>
        <div className="card-body">
          <div className="row mb-4">
            <div className="col-md-6">
              <h4 className="mb-3">Informações Gerais</h4>
              <table className="table table-bordered">
                <tbody>
                  <tr>
                    <th className="bg-light" style={{ width: '40%' }}>Nome</th>
                    <td>{circuito.nome}</td>
                  </tr>
                  <tr>
                    <th className="bg-light">Sigla</th>
                    <td>{circuito.sigla}</td>
                  </tr>
                  <tr>
                    <th className="bg-light">SEI</th>
                    <td>{circuito.SEI}</td>
                  </tr>
                  <tr>
                    <th className="bg-light">Status</th>
                    <td>
                      <span
                        className={`badge ${circuito.status === 'Ativo' ? 'bg-success' : 'bg-warning'}`}
                      >
                        {circuito.status}
                      </span>
                    </td>
                  </tr>
                  <tr>
                    <th className="bg-light">Ativo</th>
                    <td>
                      <span
                        className={`badge ${circuito.active === 'Y' ? 'bg-success' : 'bg-danger'}`}
                      >
                        {circuito.active === 'Y' ? 'Sim' : 'Não'}
                      </span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div className="col-md-6">
              <h4 className="mb-3">Datas</h4>
              <table className="table table-bordered">
                <tbody>
                  <tr>
                    <th className="bg-light" style={{ width: '40%' }}>Data de Ativação</th>
                    <td>
                      {circuito.data_ativacao ? new Date(circuito.data_ativacao).toLocaleDateString('pt-BR') : '-'}
                    </td>
                  </tr>
                  <tr>
                    <th className="bg-light">Data de Cancelamento</th>
                    <td>
                      {circuito.data_cancelamento ? new Date(circuito.data_cancelamento).toLocaleDateString('pt-BR') : '-'}
                    </td>
                  </tr>
                  <tr>
                    <th className="bg-light">Criado em</th>
                    <td>
                      {circuito.created_at ? new Date(circuito.created_at).toLocaleString('pt-BR') : '-'}
                    </td>
                  </tr>
                  <tr>
                    <th className="bg-light">Criado por</th>
                    <td>{circuito.created_by_name || '-'}</td>
                  </tr>
                  <tr>
                    <th className="bg-light">Atualizado em</th>
                    <td>
                      {circuito.updated_at ? new Date(circuito.updated_at).toLocaleString('pt-BR') : '-'}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <div className="row mb-4">
            <div className="col-md-12">
              <h4 className="mb-3">Secretaria</h4>
              {secretaria ? (
                <table className="table table-bordered">
                  <tbody>
                    <tr>
                      <th className="bg-light" style={{ width: '20%' }}>Sigla</th>
                      <td>{secretaria.sigla_pronome_tratamento}</td>
                    </tr>
                    <tr>
                      <th className="bg-light">Nome</th>
                      <td>{secretaria.nome}</td>
                    </tr>
                  </tbody>
                </table>
              ) : (
                <div className="alert alert-warning">
                  Informações da secretaria não encontradas
                </div>
              )}
            </div>
          </div>

          <div className="row mb-4">
            <div className="col-md-12">
              <h4 className="mb-3">Velocidade</h4>
              {velocidade ? (
                <table className="table table-bordered">
                  <tbody>
                    <tr>
                      <th className="bg-light" style={{ width: '20%' }}>Tipo de Serviço</th>
                      <td>{velocidade.tipo_servico}</td>
                    </tr>
                    <tr>
                      <th className="bg-light">Velocidade</th>
                      <td>{velocidade.velocidade} Mbps</td>
                    </tr>
                    <tr>
                      <th className="bg-light">Link</th>
                      <td>{velocidade.link}</td>
                    </tr>
                  </tbody>
                </table>
              ) : (
                <div className="alert alert-warning">
                  Informações de velocidade não encontradas
                </div>
              )}
            </div>
          </div>

          <div className="row mb-4">
            <div className="col-md-12">
              <h4 className="mb-3">Endereço</h4>
              {endereco ? (
                <table className="table table-bordered">
                  <tbody>
                    <tr>
                      <th className="bg-light" style={{ width: '20%' }}>CEP</th>
                      <td>{endereco.cep}</td>
                    </tr>
                    <tr>
                      <th className="bg-light">Logradouro</th>
                      <td>{endereco.tipo_logradouro} {endereco.logradouro}, {endereco.numero}</td>
                    </tr>
                    <tr>
                      <th className="bg-light">Complemento</th>
                      <td>{endereco.complemento || '-'}</td>
                    </tr>
                    <tr>
                      <th className="bg-light">Bairro</th>
                      <td>{endereco.bairro}</td>
                    </tr>
                    <tr>
                      <th className="bg-light">Cidade</th>
                      <td>{endereco.cidade}</td>
                    </tr>
                  </tbody>
                </table>
              ) : (
                <div className="alert alert-warning">
                  Informações de endereço não encontradas
                </div>
              )}
            </div>
          </div>

          <div className="d-grid gap-2 d-md-flex justify-content-md-start">
            <button
              className="btn btn-secondary"
              onClick={() => navigate('/circuito/listar')}
            >
              <ArrowLeft size={18} className="me-1" /> Voltar para Lista
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AppConsultar;