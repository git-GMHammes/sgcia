// C:\laragon\www\sgcpro\src\public\script\react_modelo_v1\frontend\src\pages\Circuito\AppForm.jsx
import React, { useState, useEffect } from 'react';
import { useForm, Controller } from 'react-hook-form';
import { X, Save } from 'lucide-react';
import CircuitoService from '../../services/circuito';
import './styles.css';

const AppForm = ({ initialData = {}, onSubmit, isEditing = false }) => {
  // Estados para armazenar dados dos selects
  const [secretarias, setSecretarias] = useState([]);
  const [velocidades, setVelocidades] = useState([]);
  const [enderecos, setEnderecos] = useState([]);
  const [loading, setLoading] = useState(true);

  // Configuração do formulário com react-hook-form
  const { register, handleSubmit, control, reset, formState: { errors } } = useForm({
    defaultValues: {
      token_csrf: "3jk4h5l6h7j8k9l0m1n2o3p4q5r6s7t8u9v0w1x2y3z4a5b6c7d8e9f0g1h2i3j4k5l6m7n8o9p0q1r2s3t4u5v6w7x8y9z0a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6a7b8c9d0e1f2g3h4i5j6k7l8m9n0o1p2q3r4s5t6u7v8w9x0y1z2a3b4c5d6e7f8g9h0i1j2k3l4m5n6o7p8q9r0s1t2u3v4w5x6y7z8a9b0c1d2e3f4g5h6i7j8k9l0m1n2o3p4q5r6s7t8u9v0w1x2y3z4a5b6c7d8e9f0g1h2i3j4k5l6m7n8o9p0q1r2s3t4u5v6w7x8y9z0a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6a7b8c9d0e1f2g3h4i5j6k7l8m9n0o1p2q3r4s5t6u7v8w9x0y1z2a3b4c5d6e7f8g9h0i1j2k3l4m5n6o7p8q9r0s1t2u3v4w5x6y7z8a9b0c1d2e3f4g9",
      id: "",
      velocidade_id: "",
      endereco_id: "",
      cadastro_cliente_id: "",
      status: "Ativo",
      active: "Y",
      sigla: "",
      nome: "",
      data_ativacao: "",
      data_cancelamento: "",
      SEI: "",
      created_by: "0",
      created_by_name: "unknown",
      updated_by: "0",
      updated_by_name: "unknown"
    }
  });

  // Carregar dados iniciais se estiver editando
  useEffect(() => {
    if (isEditing && initialData && Object.keys(initialData).length > 0) {
      reset({
        ...initialData,
        // Converter datas para o formato esperado pelo input date (YYYY-MM-DD)
        data_ativacao: initialData.data_ativacao ? new Date(initialData.data_ativacao).toISOString().split('T')[0] : '',
        data_cancelamento: initialData.data_cancelamento ? new Date(initialData.data_cancelamento).toISOString().split('T')[0] : '',
      });
    }
  }, [initialData, isEditing, reset]);

  // Carregar dados para os selects
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        // Carregando dados das APIs utilizando o serviço
        const [secretariasData, velocidadesData, enderecosData] = await Promise.all([
          CircuitoService.getSecretarias(),
          CircuitoService.getVelocidades(),
          CircuitoService.getEnderecos()
        ]);

        setSecretarias(secretariasData);
        setVelocidades(velocidadesData);
        setEnderecos(enderecosData);

        // Fallback para dados de teste caso a API não esteja disponível
        if (!secretariasData || secretariasData.length === 0) {
          console.warn('Fallback: usando dados de exemplo para secretarias');
          setSecretarias([
            { "id": 1, "sigla_pronome_tratamento": "SEDEERI", "nome": "Secretaria de Estado de Desenvolvimento Econômico, Energia e Relações Internacionais" },
            { "id": 2, "sigla_pronome_tratamento": "DRM-RJ", "nome": "Departamento de Recursos Minerais do Estado do Rio de Janeiro" },
            { "id": 3, "sigla_pronome_tratamento": "IEPAE", "nome": "Instituto Estadual de Patrimônio Artístico e Cultural" },
            { "id": 4, "sigla_pronome_tratamento": "FUNARJ", "nome": "Fundação Anita Mantuano de Artes do Estado do Rio de Janeiro" },
            { "id": 5, "sigla_pronome_tratamento": "SECT", "nome": "Secretaria de Estado de Ciência, Tecnologia e Inovação" }
          ]);
        }

        if (!velocidadesData || velocidadesData.length === 0) {
          console.warn('Fallback: usando dados de exemplo para velocidades');
          setVelocidades([
            { "id": 1, "active": "Y", "tipo_servico": "Lote 1 MPLS", "velocidade": "500", "link": "Crítico", "estoque": 24 },
            { "id": 2, "active": "Y", "tipo_servico": "Lote 1 MPLS", "velocidade": "4000", "link": "Crítico", "estoque": 5 },
            { "id": 3, "active": "Y", "tipo_servico": "Lote 1 MPLS", "velocidade": "2000", "link": "Crítico", "estoque": 5 },
            { "id": 4, "active": "Y", "tipo_servico": "Lote 1 MPLS", "velocidade": "2000", "link": "Básico", "estoque": 5 },
            { "id": 5, "active": "Y", "tipo_servico": "Lote 1 MPLS", "velocidade": "200", "link": "Crítico", "estoque": 5 }
          ]);
        }

        if (!enderecosData || enderecosData.length === 0) {
          console.warn('Fallback: usando dados de exemplo para endereços');
          setEnderecos([
            { "id": 1, "cep": "21350-600", "tipo_logradouro": "Avenida", "logradouro": "Dom Hélder Câmara", "numero": "1578", "complemento": "2º andar", "bairro": "Cavalcanti", "cidade": "Rio de Janeiro" },
            { "id": 2, "cep": "24722-380", "tipo_logradouro": "Rua", "logradouro": "Manoel João Gonçalves", "numero": "S/N", "complemento": "Casa 2", "bairro": "Tribobó", "cidade": "São Gonçalo" },
            { "id": 3, "cep": "24465-540", "tipo_logradouro": "Rua", "logradouro": "Almeida Barreto", "numero": "8096", "complemento": "Subsolo", "bairro": "Mutuapira", "cidade": "São Gonçalo" },
            { "id": 4, "cep": "27135-190", "tipo_logradouro": "Rua", "logradouro": "Fagundes Varela", "numero": "2524", "complemento": "Apto 505", "bairro": "Química", "cidade": "Barra do Piraí" },
            { "id": 5, "cep": "27140-230", "tipo_logradouro": "Rua", "logradouro": "Joaquim Figueiredo", "numero": "4272", "complemento": "Anexo", "bairro": "Muqueca", "cidade": "Barra do Piraí" }
          ]);
        }
      } catch (error) {
        console.error("Erro ao carregar dados:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  // Handler para submissão do formulário
  const handleFormSubmit = (data) => {
    // Se uma função onSubmit for fornecida pelos componentes pai, use-a
    if (onSubmit) {
      onSubmit(data);
    } else {
      // Caso contrário, implemente a lógica padrão
      console.log("Dados do formulário:", data);
      // Implementação padrão de envio para a API (exemplo)
      /*
      axios.post('/api/circuito', data)
        .then(response => {
          console.log('Sucesso:', response.data);
          // Redirecionar ou mostrar mensagem de sucesso
        })
        .catch(error => {
          console.error('Erro:', error);
          // Mostrar mensagem de erro
        });
      */
    }
  };

  if (loading) {
    return <div className="alert alert-info">Carregando formulário...</div>;
  }

  return (
    <div className="container mt-4">
      <form onSubmit={handleSubmit(handleFormSubmit)} className="needs-validation">
        <input type="hidden" {...register("token_csrf")} />
        <input type="hidden" {...register("id")} />
        <input type="hidden" {...register("created_by")} />
        <input type="hidden" {...register("created_by_name")} />
        <input type="hidden" {...register("updated_by")} />
        <input type="hidden" {...register("updated_by_name")} />

        <div className="row mb-3">
          <div className="col-md-6">
            <label htmlFor="nome" className="form-label">Nome do Circuito</label>
            <input
              type="text"
              className={`form-control ${errors.nome ? 'is-invalid' : ''}`}
              id="nome"
              {...register("nome", { required: "Nome é obrigatório" })}
            />
            {errors.nome && <div className="invalid-feedback">{errors.nome.message}</div>}
          </div>

          <div className="col-md-6">
            <label htmlFor="sigla" className="form-label">Sigla</label>
            <input
              type="text"
              className={`form-control ${errors.sigla ? 'is-invalid' : ''}`}
              id="sigla"
              {...register("sigla", { required: "Sigla é obrigatória" })}
            />
            {errors.sigla && <div className="invalid-feedback">{errors.sigla.message}</div>}
          </div>
        </div>

        <div className="row mb-3">
          <div className="col-md-6">
            <label htmlFor="cadastro_cliente_id" className="form-label">Secretaria</label>
            <select
              className={`form-select ${errors.cadastro_cliente_id ? 'is-invalid' : ''}`}
              id="cadastro_cliente_id"
              {...register("cadastro_cliente_id", { required: "Secretaria é obrigatório" })}
            >
              <option value="">Selecione uma secretaria</option>
              {secretarias.map(secretaria => (
                <option key={secretaria.id} value={secretaria.id}>
                  {secretaria.sigla_pronome_tratamento} - {secretaria.nome}
                </option>
              ))}
            </select>
            {errors.cadastro_cliente_id && <div className="invalid-feedback">{errors.cadastro_cliente_id.message}</div>}
          </div>

          <div className="col-md-6">
            <label htmlFor="velocidade_id" className="form-label">Velocidade</label>
            <select
              className={`form-select ${errors.velocidade_id ? 'is-invalid' : ''}`}
              id="velocidade_id"
              {...register("velocidade_id", { required: "Velocidade é obrigatória" })}
            >
              <option value="">Selecione uma velocidade</option>
              {velocidades.map(velocidade => (
                <option key={velocidade.id} value={velocidade.id}>
                  {velocidade.tipo_servico} - {velocidade.velocidade} Mbps - {velocidade.link}
                </option>
              ))}
            </select>
            {errors.velocidade_id && <div className="invalid-feedback">{errors.velocidade_id.message}</div>}
          </div>
        </div>

        <div className="row mb-3">
          <div className="col-md-12">
            <label htmlFor="endereco_id" className="form-label">Endereço</label>
            <select
              className={`form-select ${errors.endereco_id ? 'is-invalid' : ''}`}
              id="endereco_id"
              {...register("endereco_id", { required: "Endereço é obrigatório" })}
            >
              <option value="">Selecione um endereço</option>
              {enderecos.map(endereco => (
                <option key={endereco.id} value={endereco.id}>
                  {endereco.tipo_logradouro} {endereco.logradouro}, {endereco.numero} - {endereco.bairro}, {endereco.cidade}
                </option>
              ))}
            </select>
            {errors.endereco_id && <div className="invalid-feedback">{errors.endereco_id.message}</div>}
          </div>
        </div>

        <div className="row mb-3">
          <div className="col-md-6">
            <label htmlFor="data_ativacao" className="form-label">Data de Ativação</label>
            <input
              type="date"
              className={`form-control ${errors.data_ativacao ? 'is-invalid' : ''}`}
              id="data_ativacao"
              {...register("data_ativacao", { required: "Data de ativação é obrigatória" })}
            />
            {errors.data_ativacao && <div className="invalid-feedback">{errors.data_ativacao.message}</div>}
          </div>

          <div className="col-md-6">
            <label htmlFor="data_cancelamento" className="form-label">Data de Cancelamento</label>
            <input
              type="date"
              className="form-control"
              id="data_cancelamento"
              {...register("data_cancelamento")}
            />
          </div>
        </div>

        <div className="row mb-3">
          <div className="col-md-6">
            <label htmlFor="SEI" className="form-label">SEI</label>
            <input
              type="text"
              className={`form-control ${errors.SEI ? 'is-invalid' : ''}`}
              id="SEI"
              {...register("SEI", { required: "SEI é obrigatório" })}
            />
            {errors.SEI && <div className="invalid-feedback">{errors.SEI.message}</div>}
          </div>

          <div className="col-md-3">
            <label className="form-label">Status</label>
            <div className="mt-2">
              <Controller
                control={control}
                name="status"
                render={({ field }) => (
                  <div className="form-check form-check-inline">
                    <input
                      type="radio"
                      id="statusAtivo"
                      className="form-check-input"
                      value="Ativo"
                      checked={field.value === "Ativo"}
                      onChange={() => field.onChange("Ativo")}
                    />
                    <label className="form-check-label" htmlFor="statusAtivo">Ativo</label>
                  </div>
                )}
              />
              <Controller
                control={control}
                name="status"
                render={({ field }) => (
                  <div className="form-check form-check-inline">
                    <input
                      type="radio"
                      id="statusInativo"
                      className="form-check-input"
                      value="Inativo"
                      checked={field.value === "Inativo"}
                      onChange={() => field.onChange("Inativo")}
                    />
                    <label className="form-check-label" htmlFor="statusInativo">Inativo</label>
                  </div>
                )}
              />
            </div>
          </div>

          <div className="col-md-3">
            <label className="form-label">Ativo (Y/N)</label>
            <div className="mt-2">
              <Controller
                control={control}
                name="active"
                render={({ field }) => (
                  <div className="form-check form-check-inline">
                    <input
                      type="radio"
                      id="activeY"
                      className="form-check-input"
                      value="Y"
                      checked={field.value === "Y"}
                      onChange={() => field.onChange("Y")}
                    />
                    <label className="form-check-label" htmlFor="activeY">Sim</label>
                  </div>
                )}
              />
              <Controller
                control={control}
                name="active"
                render={({ field }) => (
                  <div className="form-check form-check-inline">
                    <input
                      type="radio"
                      id="activeN"
                      className="form-check-input"
                      value="N"
                      checked={field.value === "N"}
                      onChange={() => field.onChange("N")}
                    />
                    <label className="form-check-label" htmlFor="activeN">Não</label>
                  </div>
                )}
              />
            </div>
          </div>
        </div>

        <div className="d-grid gap-2 d-md-flex justify-content-md-end">
          <button type="button" className="btn btn-secondary me-md-2" onClick={() => window.history.back()}>
            <X size={18} className="me-1" /> Cancelar
          </button>
          <button type="submit" className="btn btn-primary">
            <Save size={18} className="me-1" /> Salvar
          </button>
        </div>
      </form>
    </div>
  );
};

export default AppForm;