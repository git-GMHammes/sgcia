// C:\laragon\www\sgcpro\src\public\script\react_modelo_v1\frontend\src\pages\Circuito\AppAtualizar.jsx
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import CircuitoService from '../../services/circuito';
import AppForm from './AppForm';
import './styles.css';

const AppAtualizar = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [circuito, setCircuito] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);

  // Buscar dados do circuito
  useEffect(() => {
    const fetchCircuito = async () => {
      if (!id) {
        setError('ID do circuito não fornecido');
        setLoading(false);
        return;
      }

      try {
        // Usando o serviço para buscar o circuito por ID
        const data = await CircuitoService.getById(id);
        setCircuito(data);
      } catch (err) {
        console.error('Erro ao buscar dados do circuito:', err);
        setError('Não foi possível carregar os dados do circuito. Por favor, tente novamente.');
      } finally {
        setLoading(false);
      }
    };

    fetchCircuito();
  }, [id]);

  // Função para lidar com a submissão do formulário de atualização
  const handleSubmit = async (formData) => {
    setLoading(true);
    setError(null);
    
    try {
      // Usando o serviço para atualizar o circuito
      const response = await CircuitoService.update(id, formData);
      
      console.log('Circuito atualizado com sucesso:', response);
      setSuccess(true);
      
      // Redirecionar após 2 segundos
      setTimeout(() => {
        navigate('/circuito/listar');
      }, 2000);
      
    } catch (err) {
      console.error('Erro ao atualizar circuito:', err);
      setError(err.response?.data?.message || 'Ocorreu um erro ao atualizar o circuito. Por favor, tente novamente.');
      setLoading(false);
    }
  };

  if (loading && !circuito) {
    return (
      <div className="container mt-4">
        <div className="card">
          <div className="card-header bg-primary text-white">
            <h2 className="mb-0">Atualizar Circuito</h2>
          </div>
          <div className="card-body text-center">
            <div className="spinner-border text-primary" role="status">
              <span className="visually-hidden">Carregando...</span>
            </div>
            <p className="mt-2">Carregando dados do circuito...</p>
          </div>
        </div>
      </div>
    );
  }

  if (error && !circuito) {
    return (
      <div className="container mt-4">
        <div className="card">
          <div className="card-header bg-primary text-white">
            <h2 className="mb-0">Atualizar Circuito</h2>
          </div>
          <div className="card-body">
            <div className="alert alert-danger" role="alert">
              {error}
            </div>
            <button 
              onClick={() => navigate('/circuito/listar')} 
              className="btn btn-primary"
            >
              Voltar para Lista
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mt-4">
      <div className="card">
        <div className="card-header bg-primary text-white">
          <h2 className="mb-0">Atualizar Circuito</h2>
        </div>
        <div className="card-body">
          {error && (
            <div className="alert alert-danger" role="alert">
              {error}
            </div>
          )}
          
          {success && (
            <div className="alert alert-success" role="alert">
              Circuito atualizado com sucesso! Redirecionando...
            </div>
          )}
          
          {!loading && !success && circuito && (
            <AppForm 
              initialData={circuito} 
              onSubmit={handleSubmit} 
              isEditing={true} 
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default AppAtualizar;