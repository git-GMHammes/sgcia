// C:\laragon\www\sgcpro\src\public\script\react_modelo_v1\frontend\src\pages\Circuito\AppListar.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus } from 'lucide-react';
import CircuitoService from '../../services/circuito';
import AppListarConteudo from './AppListarConteudo';
import './styles.css';

const AppListar = () => {
  const navigate = useNavigate();
  const [circuitos, setCircuitos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filtro, setFiltro] = useState('');
  const [paginaAtual, setPaginaAtual] = useState(1);
  // Adicionando estados para controle de paginação da API
  const [itensPorPagina, setItensPorPagina] = useState(10);
  const [totalItens, setTotalItens] = useState(0);
  const [metadados, setMetadados] = useState(null);

  useEffect(() => {
    const fetchCircuitos = async () => {
      setLoading(true);
      setError(null);

      try {
        const data = await CircuitoService.getAll(paginaAtual, itensPorPagina);
        setCircuitos([...data]);
      } catch (err) {
        console.error('Erro ao buscar circuitos:', err);
        setError('Não foi possível carregar a lista de circuitos.');
      } finally {
        setLoading(false);
      }
    };

    fetchCircuitos();
  }, [paginaAtual, itensPorPagina]);


  const circuitosFiltrados = circuitos.filter(circuito =>
    circuito.nome.toLowerCase().includes(filtro.toLowerCase())
  );

  return (
    <div className="container mt-4">
      <div className="card">
        <div className="card-header bg-primary text-white d-flex justify-content-between align-items-center">
          <h2 className="mb-0">Lista de Circuitos</h2>
          <button
            className="btn btn-light"
            onClick={() => navigate('/circuito/cadastrar')}
          >
            <Plus size={18} className="me-1" /> Novo Circuito
          </button>
        </div>
        <div className="card-body">
          {error && <div className="alert alert-danger">{error}</div>}
          {loading ? (
            <p>Carregando...</p>
          ) : (
            <AppListarConteudo circuitos={circuitosFiltrados} />
          )}
        </div>
      </div>
    </div>
  );
};

export default AppListar;